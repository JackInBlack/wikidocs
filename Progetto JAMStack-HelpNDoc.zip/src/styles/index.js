import globalStyles from './global';

export { globalStyles };
