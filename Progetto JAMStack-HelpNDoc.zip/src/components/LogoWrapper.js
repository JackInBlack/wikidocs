import styled from '@emotion/styled';
import { Link } from 'gatsby';
import React from 'react';

const LogoWrapper = () => (
  <StyledLogoWrapper>
    <LogoLink to="/">
    WIKI DOCS
    </LogoLink>
  </StyledLogoWrapper>
);

const StyledLogoWrapper = styled.div`
  p {
    margin: 0;
    font-size: 1.6rem;
  }
`;

const LogoLink = styled(Link)`
  position:relative;
  align: center;
  display: inline-block;
  text-decoration: none;
  
  font-size: 25px;
  padding: 0rem 0.5rem 0rem;
  font-weight: normal;
  color: ${p => p.theme.colors.text};
  transition: color ${p => p.theme.transition};
  &:hover,
  &:focus {
    color: ${p => p.theme.colors.primary};
  }
`;



const LogoImg = styled(Link)`
  vertical-align: middle;
  margin-top: 0px;
  margin-left: auto;
  margin-right: auto;
  padding: 0rem 0.6rem 0rem;
`;

export default LogoWrapper;
